# MedScanAI

**Understand Your Medical Reports in Seconds.**

A hackathon prototype — a single-page, self-contained web app that demonstrates how AI can translate confusing medical reports into plain language, highlight key health metrics, and generate doctor discussion questions. Includes a playful "Explain Like I'm 10" mode.

## Run it
Just open `index.html` in any browser — no build step, no dependencies beyond Google Fonts.

## Live demo (via GitHub Pages)
Enable it in **Settings → Pages → Deploy from branch → main** and it'll be live at:
`https://<your-username>.github.io/<repo-name>/`

## Tech
Vanilla HTML/CSS/JS. No frameworks, no build tools.
